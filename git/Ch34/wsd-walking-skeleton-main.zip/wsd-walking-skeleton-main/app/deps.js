export { serve } from "https://deno.land/std@0.202.0/http/server.ts";
import postgres from "https://deno.land/x/postgresjs@v3.4.2/mod.js";
export { postgres };

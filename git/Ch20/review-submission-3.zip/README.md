# Project 1: Shared shopping list

**Application Live Link:** https://binh-shopping-lists-application.onrender.com

[Click here to open the application](https://binh-shopping-lists-application.onrender.com)
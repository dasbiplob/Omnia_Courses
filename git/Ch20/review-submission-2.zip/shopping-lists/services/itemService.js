import { sql } from "../database/database.js";

const createItem = async (list_id, name) => {
  await sql`INSERT INTO shopping_list_items (shopping_list_id, name)
    VALUES (${ list_id }, ${ name })`;
};

const findCurrentItems = async (list_id) => {
  const result = await sql`SELECT * FROM shopping_list_items WHERE shopping_list_id = ${list_id} AND collected IS false ORDER BY name`;
    

  if (result && result[0]) {
    return result;
  }

  return false;
};

const findCollectedItems = async (list_id) => {
  const result = await sql`SELECT * FROM shopping_list_items WHERE shopping_list_id = ${list_id} AND collected IS true ORDER BY name`;
    

  if (result && result[0]) {
    return result;
  }

  return false;
};

const collectItem = async (id) => {
  await sql`UPDATE shopping_list_items SET collected = true WHERE id = ${ id }`;
};

const countItems = async () => {
    const rows = await sql`SELECT COUNT(*) FROM shopping_list_items`;

    if (rows && rows[0] && rows[0].count) {
      return rows[0].count;
    }
  
    return 0;
};

export { createItem, findCurrentItems, collectItem, countItems, findCollectedItems };
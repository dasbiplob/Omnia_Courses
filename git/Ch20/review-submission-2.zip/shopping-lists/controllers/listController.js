import { renderFile } from "../deps.js";
import * as listService from "../services/listService.js";
import * as itemService from "../services/itemService.js";

const responseDetails = {
  headers: { "Content-Type": "text/html;charset=UTF-8" },
};

const redirectTo = (path) => {
  return new Response(`Redirecting to ${path}.`, {
    status: 303,
    headers: {
      "Location": path,
    },
  });
};

const addList = async (request) => {
  const formData = await request.formData();
  const name = formData.get("name");

  await listService.create(name);

  return redirectTo("/lists");
};

const viewLists = async (_request) => {
  const data = {
    lists: await listService.findAllActiveLists(),
  };

  return new Response(await renderFile("lists.eta", data), responseDetails);
};

const viewList = async (request) => {
    const url = new URL(request.url);
    const urlParts = url.pathname.split("/");
  
    const data = {
      list: await listService.findById(urlParts[2]),
      currentItems: await itemService.findCurrentItems(urlParts[2]),
      collectedItems: await itemService.findCollectedItems(urlParts[2]),
    };
  
    return new Response(await renderFile("list.eta", data), responseDetails);
};

const completeList = async (request) => {
  const url = new URL(request.url);
  const urlParts = url.pathname.split("/");
  await listService.completeById(urlParts[2]);
  
  return redirectTo("/lists");
};

const count = async (_request) => {

    const data = {
        listCount: await listService.countLists(), 
        itemCount: await itemService.countItems(),
    };

    return new Response(await renderFile("main.eta", data), responseDetails);
};

export { addList, viewLists, viewList, completeList, count };
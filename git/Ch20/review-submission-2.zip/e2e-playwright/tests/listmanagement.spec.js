const { test, expect } = require("@playwright/test");

test("Main page has expected title and heading.", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle("Shared shopping lists");
  await expect(page.locator("h1")).toHaveText("Shared shopping lists");
});

test("Can create a shopping list", async ({ page }) => {
  await page.goto("/lists");
  const listName = `My list: ${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.locator("#item").click();
  await expect(page.locator(`a >> text='${listName}'`)).toHaveText(listName);
});

test("Can open an individual list page.", async ({ page }) => {
  await page.goto("/lists");
  const listName = `My list: ${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.locator("#item").click();
  await page.locator(`a >> text='${listName}'`).click();
  await expect(page.locator("h1")).toHaveText(listName);
});

test("Can go to main page from  lists page.", async ({ page }) => {
  await page.goto("/lists");
  await page.locator(`a >> text='Main page'`).click();
  await expect(page.locator("h1")).toHaveText("Shared shopping lists");
});

test("Can go to lists page from  an individual list page.", async ({ page }) => {
  await page.goto("/lists");
  const listName = `My list: ${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.locator("#item").click();
  await page.locator(`a >> text='${listName}'`).click();
  await page.locator(`a >> text='Shopping lists'`).click();
  await expect(page.locator("h1")).toHaveText("Shoppinglists");
});


# Project 1: Shared shopping list

This is a shared shopping list application. The shopping list application can be used to create shopping lists which include 
shopping list items. Main page shows statistics about shopping lists and their items. Shopping lists are listed and created on lists page. 
Different shoppings lists can be viewed from an individual shopping list page. Items can be added and collected.
Shopping lists can be deactivated after they are no longer needed. 

## Online location

The application has not been deployed to any online location.


## Starting and shutting down locally

The shared shopping list application is used with Docker Compose.

- To start the shopping list application, open up the terminal in the folder that
  contains the `docker-compose.yml` file and type `docker-compose up`.
- To stop the shopping list application, press `ctrl+C` (or similar) in the same terminal
  where you wrote the command `docker-compose up`. Another option is to open up
  a new terminal and navigate to the folder that contains the
  `docker-compose.yml` file, and then write `docker-compose stop`.

## E2E Tests with playwright

The shared shopping list application comes also with simple
[Playwright](https://playwright.dev/) configuration that provides an easy
approach for building end-to-end tests. Check out the folder `tests` within
`e2e-playwright` to get started.

To run E2E tests, launch the project using the following command:

```
docker-compose run --entrypoint=npx e2e-playwright playwright test && docker-compose rm -sf
```

Note! Once finished, this will also remove any changes to the database of your
local project.

What the e2e tests effectively do is that they start up a browser within the
docker container and examine the application programmatically based on the
tests.


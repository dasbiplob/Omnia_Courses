import { renderFile } from "../deps.js";
import * as statisticsService from "../services/statisticsServices.js";

const responseDetails = {
  headers: { "Content-Type": "text/html;charset=UTF-8" },
};


const viewStatistics = async (_request) => {
    /*
    const asd = await fetch("https://aalto-web-service.onrender.com/");
    console.log("!!!!!!!!!!!!!!!");
    console.log(asd);
    console.log("body!!!!!!!!!!!!")
    console.log(asd.body);
    console.log("json!!!!!!!!!!!!")
    const jsoni = await asd.json();
    console.log(jsoni);
    */

    const data = {
        title: "Shared shopping lists",
        list_amount: await statisticsService.getNumberOfLists(),
        item_amount: await statisticsService.getNumberOfItems(),
    };
    return new Response(await renderFile("statistics.eta", data), responseDetails);
};


export { viewStatistics };

import { renderFile } from "../deps.js";
import * as listService from "../services/listService.js";
import * as itemEntryService from "../services/itemEntryService.js";
import * as requestUtils from "../utils/requestUtils.js";

const responseDetails = {
  headers: { "Content-Type": "text/html;charset=UTF-8" },
};

const addList = async (request) => {
  const formData = await request.formData();
  const name = formData.get("name");

  await listService.create(name);

  return requestUtils.redirectTo("/lists");
};

const deactivateList = async (request) => {
    const url = new URL(request.url);
    const urlParts = url.pathname.split("/");
    await listService.deactivate(urlParts[2]);
  
    return requestUtils.redirectTo("/lists");
  };

const viewItem = async (request) => {
    const url = new URL(request.url);
    const urlParts = url.pathname.split("/");
    const list_instance = await listService.findById(urlParts[2]);
  
    const data = {
      title: "Shared shopping lists - "+list_instance.name,
      list: list_instance,
      listItems_nonCollected: await itemEntryService.getItemsInList(urlParts[2], false),
      listItems_Collected: await itemEntryService.getItemsInList(urlParts[2], true),
    };
  
    return new Response(await renderFile("item.eta", data), responseDetails);
};

const viewLists = async (request) => {
  const data = {
    title: "Shared shopping lists - all lists",
    lists: await listService.getAllLists(true),
  };

  return new Response(await renderFile("lists.eta", data), responseDetails);
};

export { addList, deactivateList, viewItem, viewLists };
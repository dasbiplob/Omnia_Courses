import { sql } from "../database/database.js";
/*
const createItemEntry = async (itemId, name) => {
    await sql`INSERT INTO
      shopping_list_items (shopping_list_id, name)
      VALUES (${itemId}, ${name})`;
  };
*/
  const createItemEntry = async (listId, name) => {
    await sql`INSERT INTO
      shopping_list_items (shopping_list_id,name)
      VALUES (${listId}, ${name})`;
  };

  /*
const findCurrentItemEntry = async (itemId) => {
  const rows = await sql`SELECT * FROM shopping_list_items
    WHERE shopping_list_id = ${ itemId } AND collected IS FALSE`;

  if (rows && rows.length > 0) {
    return rows[0];
  }

  return false;
};
*/
const getItemsInList = async (listId, collected=false) => {
    /*if (collected) {
        collected = "TRUE";
    }
    else {
        collected = "FALSE";
    }*/
    const rows = await sql`SELECT * FROM shopping_list_items
      WHERE shopping_list_id = ${ listId } AND collected = ${ collected }`;
  
    if (rows && rows.length > 0) {
      rows.sort((a, b) => a.name.localeCompare(b.name));
      return rows;
    }
  
    return false;
  };

const finishItemEntry = async (id, collect=true) => {
  await sql`UPDATE shopping_list_items
    SET collected = ${ collect } WHERE id = ${ id }`;
};

export { createItemEntry, finishItemEntry, getItemsInList };
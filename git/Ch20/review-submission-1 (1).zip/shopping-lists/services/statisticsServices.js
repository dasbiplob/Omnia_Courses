import { sql } from "../database/database.js";

const getNumberOfLists = async () => {
    const rows = await sql`SELECT COUNT(*) FROM shopping_lists`;
    return rows[0].count;
};

const getNumberOfItems = async () => {
    const rows = await sql`SELECT COUNT(*) FROM shopping_list_items`;
    return rows[0].count;
};

export { getNumberOfLists, getNumberOfItems};
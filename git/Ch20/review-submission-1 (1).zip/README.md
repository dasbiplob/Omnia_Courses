# Project 1: Shared shopping list

Shared shopping list, with statistical tools. It is possible to add and delete (deactivate) lists and view aggregated list of all active lists. Upon clicking a list, the list and all of its items are shown. In addition to viewing all list items, one can add new items to the list or "delete" items from the list. "Deleting" a list item will result it as being marked to be collected (strikethrough text). It is possible to also uncollect an item, if it was done originally by accident. By visiting base address "/", one can see statistics of the number of lists and items existing in the database (includes all lists and items, even if they are collected or deactivated).

The application follows a three-tier architecture and uses a layered architecture with views, controllers, services, and database.

The shared shopping list is shared online at: https://fitech101project1.onrender.com/.

Docker does not work with the PC configuration on which this project was done on, and as such it was not run locally. Some files for Docker might need attention, should the project be run locally. The online application is 1:1 match with all of the files within "shopping-lists" folder, and uses the database schema as described in the file in the "flyway" folder. The tests were locally tested by running Playwright via npx / npm. The tests go through f.ex. showing and adding and deactivating lists, and showing a single list with items and adding / collecting them. If one want's to run these tests against the web-hosted version, change the base url from the localhost one to the online location.


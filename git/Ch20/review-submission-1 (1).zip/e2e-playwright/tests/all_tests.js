import { test, expect } from '@playwright/test';

test('add and show lists', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle("Shared shopping lists");
  
  await page.getByRole('link', { name: 'Lists' }).click();
  await expect(page).toHaveURL('https://fitech101project1.onrender.com/lists');
   
  const listName = `List_${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.getByRole('button', { name: 'Create list!' }).click();
  await expect(page.getByRole('listitem', { name: listName })).toBeTruthy();
});


test('showing a single list', async ({ page }) => {
  await page.goto('/');

  await expect(page).toHaveTitle("Shared shopping lists");
  
  await page.getByRole('link', { name: 'Lists' }).click();
  await expect(page).toHaveURL('https://fitech101project1.onrender.com/lists');
   
  const listName = `List_${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.getByRole('button', { name: 'Create list!' }).click();
  await expect(page.getByRole('listitem', { name: listName })).toBeTruthy();

  // -------------
  await page.locator(`a >> text='${listName}'`).click();
  await expect(page.locator("h1")).toHaveText(listName);
});


test('adding and showing items in list', async ({ page }) => {
  await page.goto('/');

  await expect(page).toHaveTitle("Shared shopping lists");
  
  await page.getByRole('link', { name: 'Lists' }).click();
  await expect(page).toHaveURL('https://fitech101project1.onrender.com/lists');
   
  const listName = `List_${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.getByRole('button', { name: 'Create list!' }).click();
  await expect(page.getByRole('listitem', { name: listName })).toBeTruthy();
  
  // ------

  await page.locator(`a >> text='${listName}'`).click();
  await expect(page.locator("h1")).toHaveText(listName);

  // ------
  
  const itemName = `Item_${Math.random()}`;
  await page.locator("input[type=text]").type(itemName);
  await page.getByRole('button', { name: 'Create new item entry!' }).click();
  await expect(page.getByRole('listitem', { name: itemName })).toBeTruthy();
});


test('marking items collected', async ({ page }) => {
  await page.goto('/');

  await expect(page).toHaveTitle("Shared shopping lists");
  
  await page.getByRole('link', { name: 'Lists' }).click();
  await expect(page).toHaveURL('https://fitech101project1.onrender.com/lists');
   
  const listName = `List_${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.getByRole('button', { name: 'Create list!' }).click();
  await expect(page.getByRole('listitem', { name: listName })).toBeTruthy();
  
  // ------

  await page.locator(`a >> text='${listName}'`).click();
  await expect(page.locator("h1")).toHaveText(listName);

  // ------
  
  const itemName = `Item_${Math.random()}`;
  await page.locator("input[type=text]").type(itemName);
  await page.getByRole('button', { name: 'Create new item entry!' }).click();
  await expect(page.getByRole('listitem', { name: itemName })).toBeTruthy();

  // ------

  await page
    .getByRole('listitem')
    .filter({ name: itemName })
    .getByRole('button', { name: 'Mark collected!' })
    .click();

  await expect(page
    .getByRole('deletion', { name: itemName })
    ).toBeTruthy();

});


test('deactivate list', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle("Shared shopping lists");
  
  await page.getByRole('link', { name: 'Lists' }).click();
  await expect(page).toHaveURL('https://fitech101project1.onrender.com/lists');

  const listName = `List_${Math.random()}`;
  await page.locator("input[type=text]").type(listName);
  await page.getByRole('button', { name: 'Create list!' }).click();
  await expect(page.getByRole('listitem', { name: listName })).toBeTruthy();

  // ------

  await page.locator('li').filter({ hasText: listName}).getByRole('button', { name: 'Deactivate list!' }).click();  
  await expect (page.getByRole('listitem', { name: listName })).toBeHidden();
});